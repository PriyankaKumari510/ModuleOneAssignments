package com.cg.ui;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

class PersonJUnitTest {

	Person person = new Person();
	@BeforeClass
	public void setUp() throws Exception {
		System.out.println("Testing starts.....");
	}
	@AfterClass
	public void setUp1() throws Exception {
		System.out.println("Testing ends.....");
	}
	@Test
	public void testFirstName() {
		person.setFirstname("priyanka");
		String fname= person.getFirstname();
		assertEquals("priyanka", fname);
	}
	@Test
	public void testLastName() {
		person.setLastname("kumari");
		String lname= person.getLastname();
		assertEquals("kumari", lname);
	}
	@Test
	public void testGender() {
		person.setGender("F");
		String gender= person.getGender();
		assertEquals("F", gender);
	}
	

}
