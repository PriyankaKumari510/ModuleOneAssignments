package com.cg.ui;

public class Person {
		String Firstname;
		String Lastname;
		String Gender;
		
		public Person() {
			}
		public Person(String Firstname,String Lastname,String Gender) {
			this.Firstname=Firstname;
			this.Lastname=Lastname;
			this.Gender=Gender;
		}
		 public String getFirstname() {
			return Firstname;
		}
		public void setFirstname(String Firstname) {
			this.Firstname=Firstname;
		}
		public String getLastname() {
			return Lastname;
		}
		public void setLastname(String Lastname) {
			this.Lastname=Lastname;
		}
		public String getGender() {
			return Gender;
		}
		public void setGender(String Gender) {
			this.Gender=Gender;
		}
		
		public void printAllDetails() {
			System.out.println("Firstname:"+Firstname);
			System.out.println("Lastname:"+Lastname);
			System.out.println("Gender:"+Gender);
		}

		public static void main(String[] args) {
			Person per=new Person("Mohini","Seth","Female");
			per.printAllDetails();
			
		}

}
