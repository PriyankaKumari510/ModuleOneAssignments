package com.cg.eis.pl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

class MyMainTest {

	Employee employee =new Employee();
	@BeforeClass
	public static void setUp() throws Exception {
		System.out.println("Testing Starts.....");
	}
	@AfterClass
	public static void setUp1() throws Exception {
		System.out.println("Testing Ends.....!!!");
	}
	@Test
	public void testExceptionInvalid(){
	try {
		employee.setSalary(1000);
		assertEquals(1000, employee.getSalary());
	} catch (EmployeeException e) {
		e.printStackTrace();
	}
	
	}
}
