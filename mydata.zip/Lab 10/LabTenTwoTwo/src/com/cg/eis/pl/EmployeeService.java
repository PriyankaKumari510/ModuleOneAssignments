package com.cg.eis.pl;

public interface EmployeeService {

	public void showDetails();
}
