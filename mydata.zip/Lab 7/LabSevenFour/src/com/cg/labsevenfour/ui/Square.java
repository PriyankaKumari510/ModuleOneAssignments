package com.cg.labsevenfour.ui;

import java.util.HashMap;
import java.util.Map;

public class Square {
	Map<Integer,Integer> getSquares(int arr[]){
		Map<Integer, Integer> list = new HashMap<Integer, Integer>();
		for(int i: arr) {
			list.put(i,i*i);
		}
		System.out.println(list);
		return null;
	}

}
