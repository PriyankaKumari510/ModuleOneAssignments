package com.cg.labsevenfour.ui;

public class MyMain {

public static void main(String[] args) {
	int arr[] = {2,4,6,8};
	Square obj = new Square();
	obj.getSquares(arr);
	}

}
