package com.cg.labsevenfive.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MyMain {

	public static void main(String[] args) {
		String[] arr= {"priya", "yas","srav","sam"};
		List<String> a1 = new ArrayList<String>();
		for (String i : arr) {
			a1.add(i);
		}
	System.out.println(a1);
	Collections.sort(a1);
	System.out.println(a1);
	}
	
}
