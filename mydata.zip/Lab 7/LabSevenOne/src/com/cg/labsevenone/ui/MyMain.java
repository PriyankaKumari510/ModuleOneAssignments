package com.cg.labsevenone.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		System.out.println("enter  array size");
		Scanner scanner=new Scanner(System.in);
		int a= scanner.nextInt();
		StringBuilder sb = new StringBuilder();
		
		int[] arr = new int[a];
		int d = arr.length;	
		
		for(int i=0;i<d; i++) {
		   System.out.println("enter the" +i+ "element");
		    arr[i] = scanner.nextInt();
		  
		    }
		System.out.println("{");
	    String str9 = null;
	    for(int i=d-1; i>=0; i--) {
	    str9 = String.valueOf(arr[i]);
	    sb.append(str9);
	    if(i!=0)
		sb.append(",");
	     }
	     System.out.println(sb.reverse());
	     System.out.println("}");
	
	     String st=new String(sb);
	
	     String[] starray = st.split(",");
	     int[] intarray = new int[starray.length];
	     for (int i=0;i<starray.length;i++) {
		intarray[i]=Integer.parseInt(starray[i]);
     	}
	
   for(int i=0;i<intarray.length;i++) {
	for(int j=i+1;j<intarray.length;j++) {
		if(intarray[i]>intarray[j]) {
			int temp = intarray[i];
			intarray[i]=intarray[j];
			intarray[j]=temp;
			
		}
	}
}
for(int i=0;i<intarray.length;i++) {
	System.out.println(intarray);
}
String str10 = null;
StringBuilder sb2 = new StringBuilder();
System.out.println("{");
int i;
for( i=0;i<intarray.length;i++);{
	str10=String.valueOf(intarray[i]);
	sb2.append(str10);
	if(i != d-1)
		sb2.append(",");
}
System.out.println(sb2);
System.out.println("}");

}
}
	