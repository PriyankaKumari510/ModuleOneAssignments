package com.cg.labseventhree.ui;

import java.util.ArrayList;
import java.util.List;

public class MyMain {

public static void main(String[] args) {
	List<String> alist1 = new ArrayList<String>();
	alist1.add("1");
	alist1.add("2");
	alist1.add("3");
	alist1.add("4");
	alist1.add("5");
	List<String> alist2 = new ArrayList<String>();
	alist2.add("1");
	alist2.add("7");
	alist2.add("5");
	alist2.add("3");
	List<String> alist3 = new ArrayList<String>();
	alist3 = removeElements(alist1,alist2);
	System.out.println(alist3);
}

private static List<String> removeElements(List<String> alist1, List<String> alist2) {
alist1.removeAll(alist2);
	return alist1;
}

}
