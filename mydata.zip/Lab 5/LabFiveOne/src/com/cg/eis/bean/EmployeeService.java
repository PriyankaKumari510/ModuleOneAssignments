package com.cg.eis.bean;

public interface EmployeeService {

	void showDetails();

}
