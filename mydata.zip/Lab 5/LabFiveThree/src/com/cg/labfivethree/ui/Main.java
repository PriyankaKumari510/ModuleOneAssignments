package com.cg.labfivethree.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.labfivethree.service.Account;
import com.cg.labfivethree.service.AccountInheritance;
import com.cg.labfivethree.service.Person;

public class Main {

	public static void main(String[] args) {
		
		Scanner scr=new Scanner(System.in);
		Random rand= new Random();
		
		System.out.println("enter account holder name");
		String pname=scr.next();
		System.out.println("enter age");
		float page=scr.nextFloat();
		System.out.println("enter balance");
		double balance=scr.nextDouble();
		
		Person per=new Person();
		per.setName(pname);
		per.setAge(page);
		
		Account acc=new AccountInheritance();
		acc.setAccNum(rand.nextLong());
		acc.setBalance(balance);
		acc.setPer(per);
		String acc1=per.getName();
		
		System.out.println("account number is:" +acc.getAccNum());
		System.out.println("balance is:" +acc.getBalance());
		System.out.println("account holder name is:" +acc.getPer().getName());
		System.out.println("account holder age is:" +acc.getPer().getAge());
}
}