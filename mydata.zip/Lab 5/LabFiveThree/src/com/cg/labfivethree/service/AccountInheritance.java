package com.cg.labfivethree.service;

public class AccountInheritance extends Account {
	
	@Override
	public void Deposit(double amount) {
		balance=balance+amount;
	}
	
	@Override
	public void Withdraw(double amount) {
		balance=balance-amount;
	}

}
