package com.cg.labsixone.ui;

import java.util.Scanner;

public class MyMain {

	public MyMain() {
		// TODO Auto-generated constructor stub
      System.out.println("Person Details");
      System.out.println("_________________________");
      Scanner sc=new Scanner(System.in);
      Person p= new Person();
      
      
      System.out.println("Enter first name");
      String fname=sc.nextLine();
      try {
    	  p.setFirstname(fname);
    	  }
      catch(Exception e ) {
    	  System.out.println(e.getMessage());
      }
      
      
	System.out.println("enter lastname");
	String lname=sc.nextLine();
	try {
		p.setLastname(lname);
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}
	
	System.out.println("enter Gender");
	String gen=sc.next();
	p.setGender(gen);
	
	System.out.println("First name:"+p.getFirstname());
	System.out.println("Last name:"+p.getLastname());
	System.out.println("Gender:"+p.getGender());
	}

}
