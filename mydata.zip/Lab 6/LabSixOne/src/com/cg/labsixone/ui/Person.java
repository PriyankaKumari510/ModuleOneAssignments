package com.cg.labsixone.ui;

public class Person {

	public String firstname;
	public String Lastname;
	public String gender;
	Person(){

	};
	
	public Person(String firstname, String lastname,String gender) {
		// TODO Auto-generated constructor stub
	super();
	this.firstname=firstname;
	this.Lastname=lastname;
	this.gender=gender;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) throws Exception {
     if(firstname.isEmpty())
       System.out.println("Null Pointer Exception");
     else {
    	 this.firstname = firstname;
     }
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) throws Exception {
	     if(lastname.isEmpty())
	         System.out.println("Null Pointer Exception");
	       else {
	    	   this.Lastname = lastname;
	       }
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
}
