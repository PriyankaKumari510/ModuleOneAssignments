package com.cg.labsixtwo.service;

public class Account {
	public String name;
	public double bal;
	public float age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws Exception {
		if(age<18) {
			System.out.println("Age should be greater than 18");
	}
	else {
			this.age = age;
	}
	}
	
	}


