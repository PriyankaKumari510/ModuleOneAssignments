package com.cg.labsixtwo.service;

public class SavingAcc extends Account {
	final double miniBalance=1000;
	public SavingAcc() {
	}
	public SavingAcc(String name, double bal, float age){
		this.name=name;
		this.bal=bal;
		this.age=age;
	}
	public void withdraw(double d) {
		double b=bal;
		b-=d;
		if(b<=miniBalance)
		{
			System.out.println("no sufficient amount");
			}
		else
			bal=b;
		
		}
	@Override
	public String toString() {
		return "SavingAcc [name=" +name+ ",bal=" +bal+ ",age=" +age+ "]";
		
	}
	
	
		

}
