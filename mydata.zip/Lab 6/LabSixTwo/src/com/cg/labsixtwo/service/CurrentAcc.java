package com.cg.labsixtwo.service;

public class CurrentAcc extends Account {

	final double overDraft_limit=1000;
	public CurrentAcc() {
	}
	public CurrentAcc(String name,double bal,float age)
	{
		this.name=name;
		this.bal=bal;
		this.age=age;
	}
	public void withdraw(double d) {
		double b=bal;
		b-=d;
		if(b<=overDraft_limit)
		{
			System.out.println("you have reached your over draft limit");
			}
		else
			bal=b;
		
		}
	public String toString() {
		return "SavingAcc [name=" +name+ ",bal=" +bal+ ",age=" +age+ "]";
		
	}
	
	
		

}
