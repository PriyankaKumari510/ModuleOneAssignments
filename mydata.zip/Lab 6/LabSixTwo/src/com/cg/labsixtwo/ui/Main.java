package com.cg.labsixtwo.ui;

import java.util.Scanner;

import com.cg.labsixtwo.service.Account;
import com.cg.labsixtwo.service.CurrentAcc;
import com.cg.labsixtwo.service.SavingAcc;

 //import com.cg.labfourtwo.ui.CurrentAcc;
//importcom.cg.labfourtwo.ui.SavingAcc;

public class Main {

	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first age");
		float Age1=sc.nextFloat();
		System.out.println("enter second age");
		float Age2=sc.nextFloat();
		Account a1=new Account();
		Account a2=new Account();
		try {
			a1.setAge(Age1);
			a2.setAge(Age2);
		}catch (Exception e) {
			e.getMessage();
		}
		
		SavingAcc sa=new SavingAcc("popo",10000.0,60);
		CurrentAcc ca=new CurrentAcc("lolo",12000.0,50);
		System.out.println("Saving Account");
		System.out.println(sa);
		System.out.println("Current Account");
		System.out.println(ca);
		
		
		System.out.println("Enter the amount to withdraw from the savings accounts");
		double withdraw1=sc.nextDouble();
		sa.withdraw(withdraw1);
 
		System.out.println("Enter the amount to withdraw from the current accounts");
		double withdraw11=sc.nextDouble();
		ca.withdraw(withdraw11);

		System.out.println(" amount detials after withdrawl");
		System.out.println(sa);
		System.out.println(ca);
		sc.close();
	}
		
}	
		
