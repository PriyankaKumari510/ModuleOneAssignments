package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class MyMain {
	
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter salary");
		double esal=scanner.nextDouble();
		
		Employee emp= new Employee();
		
	try {
		emp.setSalary(esal);
	}catch(EmployeeException e) {
		System.out.println(e.getMessage());
	}
	}
}
