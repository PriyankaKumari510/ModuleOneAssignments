package com.cg.eis.bean;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.pl.EmployeeService;

public class Employee implements EmployeeService{
	
	int id;
	String name;
	double salary;
	String desigantion,InsuranceScheme;
	public int getId() {
		return id;
		
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) throws EmployeeException {
		if(salary<3000) {
			throw new EmployeeException("Salary id less than 3000");
		}
		else {
			this.salary=salary;
		}
		this.salary = salary;
	}
	public String getDesigantion() {
		return desigantion;
	}
	public void setDesigantion(String desigantion) {
		this.desigantion = desigantion;
	}
	public String getInsuranceScheme() {
		return InsuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		InsuranceScheme = insuranceScheme;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public void showDetails() {
System.out.println("\nAll Details are: " +getId()+ "\nName:" +getName()+ "\nSalary:" +getSalary()+ "\nDesignation:" +getDesigantion()+ "\nInsurance Scheme:" +getInsuranceScheme());
	}

}
