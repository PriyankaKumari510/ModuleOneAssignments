package com.cg.labasgfourone.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.labasgfourone.service.Account;
import com.cg.labasgfourone.service.Person;

public class MyMain {

	public static void main(String[] args) {
		Scanner scr=new Scanner(System.in);
		Random rand=new Random();
	System.out.println("Balance");
	double balance =scr.nextDouble();
	System.out.println("Holder name");
	String pname=scr.next();
	System.out.println("Holder age");
	float page = scr.nextFloat();
	Person accHolder = new Person();
	
	accHolder.setName(pname);
	accHolder.setAge(page);
	Account acc1=new Account();
	acc1.setAccNum(rand.nextLong());
	acc1.setBalance(balance);
    acc1.setAccHolder(accHolder);
    String acc2=accHolder.getName();
    System.out.println("Display All Data");
    System.out.println("Account Number is " +acc1.getAccNum());
    System.out.println("Balance is " +acc1.getBalance());
    System.out.println("Account Holder name is " +acc1.getAccHolder().getName());
    System.out.println("Age is " +acc1.getAccHolder().getAge());   
	if(acc2.equals("smith")) {
		System.out.println("Deposit to smith account" +acc1.Deposit(5000)+ "Balance available" +acc1.getBalance());
	}
	else if(acc2.equals("kathy")) {
		System.out.println("Withdraw from kathy account" +acc1.withDraw(3000)+ "Balance available" +acc1.getBalance());
			
	}
	

	scr.close();
}	
}
	

