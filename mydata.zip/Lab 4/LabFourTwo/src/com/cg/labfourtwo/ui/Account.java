package com.cg.labfourtwo.ui;

public class Account {
	
	String name;
	double bal;
	float age;
	public String getname() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}

}
