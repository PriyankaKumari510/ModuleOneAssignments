package com.cg.labfourtwo.ui;

public class CurrentAcc extends Account {
	 
	final double overdraft_Limit=1000;
	
	public CurrentAcc() {
	}
	
	public CurrentAcc(String name,double bal,float age) {
		this.name=name;
		this.bal=bal;
		this.age=age;
		
	}
	public void withdraw(double d) {
		double b=bal;
		b-=d;
		if(bal>=overdraft_Limit)
		{
			System.out.println("you reached your overdraft_limit");
			
		}
		else
			bal=b;
		
	}
	@Override
	public String toString() {
		return "CurrentAcc [name=" + name +",bal=" + bal + " ,age=" + age + "]";
	}


}
