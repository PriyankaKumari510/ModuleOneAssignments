package com.cg.labfourtwo.ui;

public class SavingAcc extends Account {
	
	final double minibalance=1000;
	public SavingAcc() {
	}
	
	public SavingAcc(String name,double bal,float age) {
		this.name=name;
		this.bal=bal;
		this.age=age;
		
	}
	public void withdraw(double d) {
		double b=bal;
		b-=d;
		if(b<=minibalance)
		{
			System.out.println("no sufficient amount to withdraw");
			
		}
		else
			bal=b;
		
	}
	@Override
	public String toString() {
		return "SavingAcc [name=" + name +",bal=" + bal + " ,age=" + age + "]";
	}

}


	