package com.cg.labelevenfive;

public class Factorial {
	public int calculate(int num) {
		int fact=1;
		for(int i=1; i<=num; i++) {
			fact=fact*i;
			
		}
		return fact;
	}

}
