package com.cg.labtwofour.ui;



public class MyMain {

  public String firstname;
  public String lastname;
  char gender;
 long phone;
 public MyMain()
 {
 }
public MyMain(String first, String last,char g,long ph){
  firstname=first;
  lastname=last;
  gender=g;
  phone=ph;
  }

public long getPhone(){
return phone;
}

public void setPhone(long phone){
 this.phone=phone;
}

public String getFirstname(){
return firstname;
}

public void setFirstname(String firstname){
this.firstname=firstname;
}

public String getLastname(){
return lastname;
}

public void setLastname(String lastname){
this.lastname=lastname;
}

public char getGender(){
return gender;
}

public void setGender(char gender){
this.gender=gender;
}
}

class PersonMain
{
 public static void main(String[] args) {
 
	 MyMain p=new MyMain("priyanka","Kumari",'f',709504719);
     
 System.out.println("Person Details: ");
 System.out.println("------------");
 System.out.println("First name:"+p.firstname);
 System.out.println("Last name:"+p.lastname);
 System.out.println("Gender:"+p.gender);
 System.out.println("Phone:"+p.phone);
 }
}