package com.cg.labtwofive.ui;
import com.cg.labtwofive.ui.MyMain.gender;

public class MyMainApp {

	public static void main(String[] args) {
		
	MyMain p=new MyMain("Priya","Kumari");
	System.out.println("FirstName:"+p.getfirstname());
	System.out.println("LastName:"+p.getlastname());
	String g=gender.M.toString();
	String gend=args[0];
	if(gend.equalsIgnoreCase(g))
	{
	System.out.println("gender:F");
		}
	
	else
	{
	System.out.println("gender:M");
		}
	}
}
