package com.cg.labtwofive.ui;

public class MyMain {

	  public String firstname;
	  public String lastname;
	  public MyMain()
	  {
	  }
	  public MyMain(String first, String last)
	  {
		  firstname=first;
		  lastname=last;  
	  }
	      public String getfirstname(){
		  return firstname;
		  }

		  public void setfirstname(String firstname){
		  this.firstname=firstname;
		  }

		  public String getlastname(){
		  return lastname;
		  }

		  public void setlastname(String lastname){
		  this.lastname=lastname;
		  }
    enum gender{M,F}

}

