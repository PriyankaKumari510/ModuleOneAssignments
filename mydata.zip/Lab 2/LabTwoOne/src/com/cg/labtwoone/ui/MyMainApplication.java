package com.cg.labtwoone.ui;

public class MyMainApplication {
String FirstName = "Priyanka";
String LastName = "Kumari";
char Gender= 'F';
int Age = 20;
double Weight = 48;

void printDetails()
{
 System.out.println("Person Details: ");
 System.out.println("------------");
 System.out.println("First name:"+FirstName);
 System.out.println("Last name:"+LastName);
 System.out.println("Gender:"+Gender);
 System.out.println("Age:"+Age);
 System.out.println("Weight:"+Weight);
}
public static void main(String args[])
 {
  MyMainApplication p = new  MyMainApplication();
  p.printDetails();
 }
}
