package com.cg.labtwothree.ui;

public class MyMain {

  public String firstname;
  public String lastname;
  char gender;
 public   MyMain()
 {
 }
public  MyMain(String first, String last,char g){
  firstname=first;
  lastname=last;
  gender=g;
  }


public String getFirstname(){
return firstname;
}

public void setFirstname(String firstname){
this.firstname=firstname;
}

public String getLastname(){
return lastname;
}

public void setLastname(String lastname){
this.lastname=lastname;
}

public char getGender(){
return gender;
}

public void setGender(char gender){
this.gender=gender;
}
}

class PersonMain
{
 public static void main(String args[]) {
    MyMain p=new MyMain("priyanka","Kumari",'f');
     
 System.out.println("Person Details: ");
 System.out.println("------------");
 System.out.println("First name:"+p.firstname);
 System.out.println("Last name:"+p.lastname);
 System.out.println("Gender:"+p.gender);
 }
}
 
 

