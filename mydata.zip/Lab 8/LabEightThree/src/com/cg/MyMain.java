package com.cg;

public class MyMain implements Runnable {

	static MyMain obj1;
	static MyMain obj2;
	static Thread t1;
	static Thread t2;
	
	
	private int num=(int)(Math.random()*10);
	private int fact=1;
	int i = num;
	public void run() {
		synchronized(t1) {
			if(Thread.holdsLock(t1)) {
				System.out.println("number"+num);
				
			}
			synchronized(t2) {
				if(Thread.holdsLock(t2)) {
                while(i>0) {
                	fact=fact*i;
                	i--;
                	}
                System.out.println("factorial of "+num+ " is "  +fact);
				}
			}
		}
		
	}
	public static void main(String[] args)throws InterruptedException {
		obj1=new MyMain();
		obj2=new MyMain();
		t1=new Thread(obj1);
		t2=new Thread(obj2);
		t1.start();
		t2.start();
		t1.sleep(2000);
	}
}
