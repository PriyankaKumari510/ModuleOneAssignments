package com.cg;

import java.util.Queue;
import java.util.Random;

public class CustomerThread implements Runnable {
	
	private Queue sharedQ;
	private final int MAX_SIZE;
	
	public CustomerThread(Queue sharedQ,int MAX_SIZE) {
		super();
		this.sharedQ = sharedQ;
		this.MAX_SIZE = MAX_SIZE;
		
	}

	@Override
	public void run() {
		
		while(true) {
			synchronized(sharedQ) {
				while(sharedQ.size()==MAX_SIZE) {
					try {
						System.out.println("All products are given to biller");
						sharedQ.wait();
					}catch(Exception e) {
						System.out.println("Error:"+e);
					}
				}
				Random random = new Random();
                int i= Math.abs(random.nextInt(100));
				System.out.println("Product:"+i);
				sharedQ.add(i);
				sharedQ.notify();
			}
		}
		
	}

}
