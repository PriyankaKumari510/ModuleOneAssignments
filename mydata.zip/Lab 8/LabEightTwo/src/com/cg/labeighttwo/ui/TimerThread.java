package com.cg.labeighttwo.ui;

public class TimerThread implements Runnable {
	
	public static void main(String[] args) {
		TimerThread timerThread = new TimerThread();
		Thread thread = new Thread(timerThread);
		thread.start();
		
	}
	public void run() {
		for(int i=0; i<5;i++) {
			try {
				Thread.currentThread().sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Timer");
		}
	}

}
