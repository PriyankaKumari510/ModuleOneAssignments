package com.cg.labthreeseven.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) 
	{
		Scanner scr= new Scanner(System.in);
		System.out.println("enter any string ending with_job");
		String str=scr.next();
		
		if(str.length()>=12) {
			System.out.println(validate(str));
		}
		else {
			System.out.println("not validated");
		}
	}
	public static boolean validate(String str) {
		if(str.endsWith("_job")) {
			return true;
		}
		else
			return false;
	}
}
            