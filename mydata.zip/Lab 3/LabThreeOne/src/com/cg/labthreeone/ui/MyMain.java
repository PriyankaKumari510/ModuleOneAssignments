package com.cg.labthreeone.ui;
import java.util.Scanner;

public class MyMain {
	public static void main(String[] args) {
		Scanner scr=new Scanner(System.in);
		System.out.println("enter string");
		String str = scr.next();
		
		System.out.println(str.concat(str));
		System.out.println(replaceCharacter(str));
        System.out.println(removeDuplicates(str));
        System.out.println(upperCase(str));
        
	}
	public static String removeDuplicates(String str3) {
		char[] carray = str3.toCharArray();
		String Dupstr="";
		for(char value: carray) {
			if(Dupstr.indexOf(value) == -1) {
				Dupstr+=value;
				
			}
		}
		return Dupstr;
		
	}
public static String replaceCharacter(String str) {
	for(int i=0; i<+str.length();i++) {
		if(i%2 != 0) {
			str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
			}
	}
return str;
}
public static String upperCase(String str) {
	String word = "";
	for(int i=0;i<str.length();i++) {
		char ch=str.charAt(i);
		if(i%2 != 0) {
			
		ch=Character.toUpperCase(ch);
			
	}
		word = word+ch;
	
}
return word;
}
}