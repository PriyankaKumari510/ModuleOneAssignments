package com.cg.labthreefour.ui;


	 import java.time.LocalDate;
	 import java.time.format.DateTimeFormatter;
	 import java.util.Scanner;
	 import java.time.Period;


	 public class MyMain {

	 	public static void main(String[] args) {
	 		
	 		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	 		Scanner scr1=new Scanner(System.in);
	 		System.out.println("Enter the first date in dd/mm/yyyy");
	        String date1=scr1.next();
	        LocalDate myDate=LocalDate.parse(date1,format);
	        Scanner scr2=new Scanner(System.in);
	        System.out.println("Enter the second date in dd/mm/yyyy");
	        String date2=scr2.next();
	        LocalDate Datetwo=LocalDate.parse(date2,format);
	        Period diff=myDate.until(Datetwo);
	        System.out.println("Days:"+diff.getDays());
	        System.out.println("Months:"+diff.getMonths());
	        System.out.println("Years:"+diff.getYears());


	 	}
	 }

