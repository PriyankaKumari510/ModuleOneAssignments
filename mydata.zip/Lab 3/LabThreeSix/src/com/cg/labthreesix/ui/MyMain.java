package com.cg.labthreesix.ui;


import java.time.LocalDateTime;

import java.time.ZonedDateTime;

public class MyMain {
	public static void main(String[] args) {
		
		LocalDateTime today=LocalDateTime.now();
		System.out.println(today);
		
		ZonedDateTime ZoneIndia=ZonedDateTime.now();
		System.out.println(ZoneIndia);
		
		ZonedDateTime ZoneFrance=ZonedDateTime.now(java.time.ZoneId.of("Europe/Paris"));
		System.out.println(ZoneFrance);
		
		ZonedDateTime ZoneTokyo=ZonedDateTime.now(java.time.ZoneId.of("Asia/Tokyo"));
		System.out.println(ZoneTokyo);
		
		ZonedDateTime ZoneNew_York=ZonedDateTime.now(java.time.ZoneId.of("America/New_York"));
		System.out.println(ZoneNew_York);
		
	}

}
