package com.cg.labthreefive.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class MyMain {
public static void main(String[] args) {
		
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the date in dd/mm/yyyy");
        String date=scr.next();
        LocalDate myDate=LocalDate.parse(date,format);
        LocalDate Date;
        Date=myDate.plusMonths(5);
        Date=Date.plusYears(3);
        
        System.out.println("Expiry Date:"+Date);
        
}
}
