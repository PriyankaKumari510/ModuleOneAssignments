package com.cg.labthreeeight.ui;

	import java.util.Scanner;

	public class MyMain {

		public static void main(String[] args) 
		{
			Scanner scr1= new Scanner(System.in);
			System.out.println("enter count of elements:");
			int i=scr1.nextInt();
			String temp;
			String names1[]=new String[i];
			String names2[]=new String[i];
			Scanner scr2=new Scanner(System.in);
			System.out.println("enter all elements");
			for(int j=0;j<i;j++) {
				names1[j]= scr2.nextLine();
		}
		
			for(int l=0;l<i;l++) {
               for(int k=l+1;k<i;k++) {
                  if((names1[l].compareTo(names1[k]))>0) {
            		temp=names1[l];
            		names1[l]=names1[k];
            		names1[k]=temp;
            	}
            	}
               
			}
			for(int j=0;j<i;j++)
			{
				System.out.println(names1[j]);
			}
			
	for(int n=0;n<i;n++) {
		if(n<=(i/2)) {
			names2[n]=names1[n].toUpperCase();
		}
			else
				names2[n]=names1[n].toLowerCase();	
		}
		for(int m=0;m<i;m++) {
			System.out.println(names2[m]);
	}
	}
}
