package com.cg.labthreethree.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.time.Period;



public class MyMain {

	public static void main(String[] args) {
		
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the date in dd/mm/yyyy");
        String date=scr.next();
        LocalDate myDate=LocalDate.parse(date,format);
        LocalDate today=LocalDate.now();
        Period diff=myDate.until(today);
        System.out.println("Days:"+diff.getDays());
        System.out.println("Months:"+diff.getMonths());
        System.out.println("Years:"+diff.getYears());


	}
}
