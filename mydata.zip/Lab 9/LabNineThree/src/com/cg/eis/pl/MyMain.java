package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.service.EmployeeServiceImpl;


public class MyMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Employee emp=new Employee();
		
		System.out.println("Enter name");
		String empName=scanner.next();
		System.out.println("Enter id");
		int empId =scanner.nextInt();
		System.out.println("Enter Designation");
		String empDesignation=scanner.next();
		System.out.println("Enter Salary");
		int empSalary=scanner.nextInt();
		System.out.println("Enter scheme");
		String empScheme=scanner.next();
        
		emp.setName(empName);
		emp.setId(empId);
		emp.setDesignation(empDesignation);
        emp.setInsuranceScheme(empScheme);
		emp.setSalary(empSalary);
		
		System.out.println(emp.toString());
		EmployeeServiceImpl service = new EmployeeServiceImpl();
		
		double sal=emp.getSalary();
		String des = emp.getDesignation();
		service.InsuranceScheme(sal,des);
		service.FileObject(emp);
		service.FileObjectDetails(emp);
	}

}
