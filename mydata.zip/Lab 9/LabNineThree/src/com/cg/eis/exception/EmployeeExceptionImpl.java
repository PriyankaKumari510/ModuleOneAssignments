package com.cg.eis.exception;

public class EmployeeExceptionImpl extends Exception {
	public EmployeeExceptionImpl() {
		super();
	}
	public EmployeeExceptionImpl(String arg0) {
		super(arg0);
	}

}
