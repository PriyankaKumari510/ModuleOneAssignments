package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;

public interface IEmployeeService {
	public void InsuranceScheme();  
	public void FileObjectDetails(Employee emp);
    public void FileObject(Employee details);
    public void InsuranceScheme(double sal, String des);

}
