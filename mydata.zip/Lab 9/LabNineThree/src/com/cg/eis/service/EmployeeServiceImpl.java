package com.cg.eis.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.exception.IEmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	@Override
	public void InsuranceScheme(double sal, String des) {
	
	}
	
	public void InsuranceScheme(int salary,String designation) throws EmployeeExceptionImpl{
		
		if(salary < 3000) {
			throw new EmployeeExceptionImpl(IEmployeeException.ERROR1);
		}
		if((salary>5000 && salary<20000) && designation.equals("systemassociate")) {
		}
		if((salary>20000 && salary<40000) && designation.equals("programmer")) {
			System.out.println("scheme B");
	}
		if((salary>40000) && designation.equals("manager")) {
			System.out.println("scheme A");
}
		else {
			System.out.println("salary or designation is not matched.please enter correct details");
		}
		}
	
	@Override
	public void FileObject(Employee details) {
		File file=new File("Employee.txt");
		FileOutputStream fos;
		try {
			fos=new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(details);
			oos.close();
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			
		}catch(IOException e) {
			
		}
	}
	
	@Override
	public void FileObjectDetails(Employee emp) {
		try {
			File file =new File("");
			FileInputStream fileInputStream;
			fileInputStream = new FileInputStream(file);
			ObjectInputStream inputStream;
			inputStream = new ObjectInputStream(fileInputStream);
			Employee empOne=(Employee) inputStream.readObject();
			System.out.println(empOne.getId());
			System.out.println(empOne.getName());
			System.out.println(empOne.getSalary());
			System.out.println(empOne.getDesignation());
			System.out.println(empOne.getInsuranceScheme());
			
			inputStream.close();
		    fileInputStream.close();	
		} catch(IOException e1){
			e1.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void InsuranceScheme() {
		// TODO Auto-generated method stub
		
	}
}