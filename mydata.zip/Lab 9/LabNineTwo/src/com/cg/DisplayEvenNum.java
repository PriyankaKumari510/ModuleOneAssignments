package com.cg;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DisplayEvenNum {

	public static void main(String[] args) {
		int num=0;
		File file= new File("source.txt");
		try {
			Scanner scanner=new Scanner(file);
			scanner.useDelimiter("\\D");
			while(scanner.hasNext()) {
				num=scanner.nextInt();
				if(num%2==0) {
					System.out.println(num);
				}
			}
			scanner.close();	
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
