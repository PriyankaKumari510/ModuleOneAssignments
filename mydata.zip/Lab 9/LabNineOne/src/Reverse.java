import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reverse {

	public static void main(String[] args) {
		try {
			FileReader fr= new FileReader("source.txt");
			FileWriter fw= new FileWriter("target.txt");
			BufferedReader br=new BufferedReader(fr);
			
			String data;
			while((data=br.readLine())!=null) {
				String[] words = data.split(" ");
				for(String a : words) {
					StringBuilder builder = new StringBuilder(a);
					StringBuilder b= new StringBuilder();
					b.append(builder.reverse().toString());
					b.append(" ");
					fw.write(b.toString());
					System.out.println(b);
				}
			}
			fw.close();
			fr.close();
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
